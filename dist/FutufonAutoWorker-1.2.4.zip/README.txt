FUTUFON AUTOWORKER 1.2.4
For My Winter Car with MSCLoader for My Winter Car.
Author: 2Baikal. MIT license.

PUBLIC TEST RELEASE
The four work modes in 1.1.1 were tested in-game by the author. 1.2.4 passes automated scheduling, model and controlled geometry checks. It fixes false floor-space errors from combined factory floor/wall bounds; offline checks against the installed collision meshes resolve 27 false intersections while retaining wall rejection. The new floor placement, left-opening assembly lid, live mode transitions, lower-layer graphics and expanded HUD still need wider in-game testing.

INSTALL
Close the game. Copy Mods/FutufonAutoWorkerMscModLoader.dll from this archive into your active MSCLoader Mods folder. Replace the previous DLL when updating. Install MSCLoader separately:
https://www.nexusmods.com/mywintercar/mods/3
Built against MSCLoader 1.4.2 for My Winter Car. Other loaders have not been tested.

START
Clock in at the factory, stand by a clear work table and look down at the tabletop. Choose settings under MSCLoader > Futufon AutoWorker, then press F8.
The default interface language is Russian. Select English in the Language setting. All mod settings, option labels, help and keybinding names follow that language without bilingual labels. Values and assigned keys are retained.

MODES
1. Full cycle: automatic supplies, assembly, carton packing and pallet delivery.
2. Manual delivery: automatic supplies, assembly and carton packing; carry the full carton yourself.
3. Loose packages: automatic supplies and assembly; eleven floor towers of up to four, to your left. Pack and deliver manually.
4. Manual supplies: bring and open supply containers on the same table; assembly into floor towers of four to your left is automatic. Replenishing, packing and delivery are manual.

Leave clear table space for assembly and supply containers, and floor space to your left for eleven towers (44 packages). Carton modes place the large box farther back on your right, with room for its open flaps. The assembly lid opens left. Automatic delivery needs free player-pallet slots.

CONTROLS AND SETTINGS
F8: start, soft pause, resume.
F6: show/hide HUD.
Next mode: assign a key in MSCLoader keybindings; cycles 1 > 2 > 3 > 4 > 1.
Batch volume: assign a separate key; switches one carton / pallet for the next run.
Mode and volume selection work before F8 and while paused; the HUD updates immediately.
Write logs and snapshots: unassigned by default. The Write logs key controls the GUI logging toggle; snapshots require logging to be enabled.
All keys can be remapped.
Volume: one batch of 44, or a run based on free pallet slots at start, up to 176 packages.
Speed: 10–100%.

Pause and mode changes finish the current small package first. Selecting a mode while paused does not start the worker. Mixed-mode runs keep old stacks and carton contents where they are; existing stacks are not automatically packed. The total volume remains fixed and can include both stacks and a partial carton.
Automation/stack progress persists within the game session. After reloading, start a new run; shipping-carton contents saved by the game can be continued.
Manually inserted complete packages are checked before assembly and packing, including after a pause. If 17 are already inside, only 27 more are made. A full carton needs no new parts. Manually packing this run's own stacked output does not count it twice.

HUD
Progress, task, supplies, free pallet slots, supervisor status, clock-in/out times and the game's signed overtime balance. Last-shift times are reconstructed from the game's saved clock-in and duration after loading. Overtime changes according to native clock-out and daily accounting.
Selected mode/volume are visible before start; accumulated game idle time is labelled in minutes.
Lunch/end-of-shift notifications and a Tuesday-only 13:10 meeting reminder are included.
Lower filled carton layers are shown using visual-only meshes; native contents and delivery accounting are retained.

FEEDBACK
Include the mod/game/MSCLoader versions, mode/volume/speed, reproduction steps, expected/actual result, other factory-related mods and whether it happened after a reload.
File logging is off by default; no AutoWorkerLogs folder or new file is created while opted out, including for snapshots/errors. Enable Write logs (diagnostics) in the mod settings to record a diagnostic session in Mods/AutoWorkerLogs beside the DLL. Turn it off after reproducing the issue; the file closes immediately. The toggle is saved by MSCLoader. Screenshots or videos are useful.
Compatibility with other factory-job mods is not fully tested. Manual modes need your participation and do not guarantee zero supervisor-recorded idle time.

UNINSTALL
Pause with F8, close the game and remove the mod DLL.

Thanks to piotrulos for MSCLoader. Developed with AI-assisted coding using Codex.
See README-RU.md for detailed Russian instructions and LICENSE for the MIT license.
